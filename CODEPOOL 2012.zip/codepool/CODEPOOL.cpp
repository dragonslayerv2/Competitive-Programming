//-----------------------------------------------------------------------------------------
//				Codepool Problem Solution
//					LITERATI 2012
//-----------------------------------------------------------------------------------------
//
//	Shobhit Saxena (111392), 	Mobile No: 9034493057
//-----------------------------------------------------------------------------------------
   


#include <iostream>
#include <string>
#include<conio.h>

using namespace std;
//------------------------------------------------------------------------
unsigned long int number;
void recurse(int width, int position, string baseString);
//------------------------------------------------------------------------
struct node
{
   char*p;
   node*next;    
}*p1=NULL,*p2=NULL,*p3=NULL,*p4=NULL;

void createnode(char * n,node *(*head))
{
    node *s=new node;
    if(!s)
          {printf("\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b                            \b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\bOut of range!!!\n");return;}
    s->p=n;
    s->next=NULL;
    if(*head==NULL)
                  *head=s;
    else
    {
     s->next= *head;
    *head=s;
    }
}
//---------------------------------------------------------------------------
void showdata( node *head)
{
 node *temp=head;
 while(temp)
 {
 printf(temp->p);
 cout<<endl;
 temp=temp->next;
 } 
}
//--------------------------------------------------------------------------------------------
void deletenode(node *(*head))
{
 node *temp;
 while(*head)
 {
 temp=*head;
 *head=(*head)->next;
 delete temp;
}
}

//-------------------------------------------------------------------------------------------
struct node2
{
   unsigned long int n;
   node2 *next;    
}*top=NULL,*h=NULL;

void createnode2(unsigned long int n)
{
    node2 *s=new node2;
    if(!s)
          {printf("Out of memory");return;}
    s->n=n;
    s->next=NULL;
    
    if(h==NULL&&top==NULL)
                  h=top=s;
    else
    {
     top->next= s;
    top=s;
    }
}
//---------------------------------------------------------------------------------------
unsigned long int pop()
{
 node2 *temp;
 temp=h;
 int n=temp->n;
  if(h!=top)
            h=h->next;
  else
            h=top=NULL;
 delete temp;
 return n;
}
//---------------------------------------------------------------------------
#define TRUE 1
#define FALSE 0
char chars[]={'a','b','c','d','e','f','g','A','B','C','D','E','F','G'};
    char c[]={'A','a','B','b','C','c','D','d','E','e','F','f','G','g'};
    unsigned long int v[]={5,1,50,10,500,100,5000,1000,50000,10000,500000,100000,5000000,1000000};    
//------------------------------------------------------------------------------------------------    
    int length;
//----------------------------------------------------------------------------
void reoccur()
{
     if(!top) {getch();exit(0);}
              cout<<"Please Wait...Computing Ans.";
           length=-1;
           number=pop();
           if(number>5000000)
           {
                             cout<<"\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b                            \b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b";cout<<"Out of Range";reoccur();
           }
           int i=1;
           while(1)
                   {
                      
                      recurse(i,0,"");
                      i++;
    
                   }
 
}

//---------------------------------------------------------------------------------
int sequence(char *a)
{
	int l=strlen(a);
	int x=0;
	int z=0;
	for(int i=l-1;i>=0;i--)
	{
	for(int j=0;j<15;j++)
	{       if(i==l-1&&a[i]==c[j])
		     {z=v[j];}
		if(a[i]==c[j])
		{
			int  y=x>v[j]?-1:+1;
			if(y>0)
			{
				if(v[j]<z)
				{ return FALSE;}
				else
				{
					z=v[j];
				}
			}
			x=v[j];
			break;
		}
	}
	
}
return TRUE;
}
//--------------------------------------------------------------------------------------
void R2()
{
     node *temp=p1;
while(temp)
{
	if(sequence(temp->p)==TRUE)
	{
		createnode(temp->p,&p2);
	}
	temp=temp->next;
}
 deletenode(&p1);
}
//-----------------------------------------------------------------------------------------
int negative(char a[])
{
    int l=strlen(a);
	int x=0;

	int n=0;
	for(int i=l-1;i>=0;i--)
	{
	for(int j=0;j<15;j++)
	{
		if(a[i]==c[j])
		{
			int  y=x>v[j]?-1:+1;
			if(y<0)
			{
				n++;
			}
			x=v[j];
			break;
		}
	}
}

return n;
}
//----------------------------------------------------------------------------------------------
void R3()
{
int n=0;
node *temp=p2;
n=negative(temp->p);
createnode(temp->p,&p3);
temp=temp->next;
while(temp)
{
 int r=negative(temp->p);

	if(r<n)
	{
		n=r;
		deletenode(&p3);
	
	}
	if(r==n)
		createnode(temp->p,&p3);
temp=temp->next;
}

deletenode(&p2);

}

//-------------------------------------------------------------------------------------------
int soi(char *a)
{
 int l=strlen(a);
	int x=0;

	int n=0;
	for(int i=l-1;i>=0;i--)
	{
	for(int j=0;j<15;j++)
	{
		if(a[i]==c[j])
		{
			int  y=x>v[j]?-1:+1;
			if(y<0)
			{
				n=n+i;
			}
			x=v[j];
			break;
		}
	}
}

return n;
}
//------------------------------------------------------------------------------------------

void R4()
{
int n=0;
node *temp=p3;
n=soi(temp->p);
createnode(temp->p,&p4);
temp=temp->next;
while(temp)
{
    int x=soi(temp->p);
	

	if(x>n)
	{
		n=x;
		deletenode(&p4);
	}
	if(x==n)
		createnode(temp->p,&p4);
		
	temp=temp->next;
}

deletenode(&p3);
}

//------------------------------------------------------------------------------------------------
    
unsigned long int sti(char *p)
{
         if(strcmp(p,"0")==0)
                             return 0;
unsigned long int number=0;
int l=strlen(p);
int x=0;
for(int i=l-1;i>=0;i--)
{
	for(int j=0;j<15;j++)
	{
		if(p[i]==c[j])
		{
			long int  y=x>v[j]?(-1)*v[j]:v[j];
			number=number+y;
			x=v[j];
			break;
		}
	}
}
	return number;
}
//----------------------------------------------------------------------------
    
        void checkstring(string password) {
    int x=password.size();
    char *p=new char[x+1];
    
    std::strcpy(p, password.c_str());
    if(x>length&&length!=-1)
    {
                            
                            R2();
                            R3();
                            R4();
                            cout<<"\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b                            \b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b";
                            cout<<p4->p<<endl;
                            deletenode(&p4); 
                            //-------------------------****----------------------------
                            reoccur();
                            exit(1);
    }
    if (sti(p)==number) {
    length=x;
    
    createnode(p,&p1);
    }
    else
    {
        delete[] p;
    }
    }
//-----------------------------------------------------------------------

    
//---------------------------------------------------------------
    void recurse(int width, int position, string baseString) {
    for(int i=0;i<14;i++) {
    if (position < width-1) {
    recurse(width, position + 1, baseString+chars[i]);
    }
    checkstring(baseString+chars[i]);
    }
    }
//---------------------------------------------------------------    
    
    
int main() 
{
    unsigned long int xyz;
 while(1)
 {
         cin>>xyz;
         if(xyz==0)
                   break;
         createnode2(xyz);
         
 }
 reoccur();
 return 1; 
}    
//-----------------------------------------------------------------------------------------
//				Codepool Problem Solution
//					LITERATI 2012
//-----------------------------------------------------------------------------------------
//
//	Shobhit Saxena (111392), 	Mobile No: 9034493057
//-----------------------------------------------------------------------------------------